This folder contains a Windows build of the game.

How to run:
 - Make sure you have the SDL runtime DLL (SDL3.dll or SDL2.dll) in the same folder as the executable.
 - Run the executable: test.exe

If you built this with cross-compile on Linux, copy the Windows SDL runtime into this folder or let the script find it under src/thirdparty.
